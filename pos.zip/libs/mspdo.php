<?php
defined('SAFE')or die('Not allowed');
/**
 * MysqliPDO Class
 *
 * @category  Database Access
 * @package   MysqliDb
 * @author    Jeffery Way <jeffrey@jeffrey-way.com>
 * @author    Josh Campbell <jcampbell@ajillion.com>
 * @copyright Copyright (c) 2010
 * @license   http://opensource.org/licenses/gpl-3.0.html GNU Public License
 * @version   1.1
 **/
 require_once(ZEND."/Loader.php");

	Zend_Loader::loadClass("Zend_Registry");

	Zend_Loader::loadClass("Zend_Db_Adapter_Mysqli");

	Zend_Loader::loadClass("Zend_Db_Adapter_Pdo_Mysql");
	Zend_Loader::loadClass("Zend_Db_Statement_Mysqli");
	Zend_Loader::loadClass("Zend_Db_Select");
	Zend_Loader::loadClass("Zend_Db_Table");
	Zend_Loader::loadClass("Zend_Db_Table_Row");
	Zend_Loader::loadClass("Zend_Db_Table_Rowset");
class MsPdo
{
protected $prefix;
    /**
     * Static instance of self
     *
     * @var MysqliDb
     */
    protected static $_instance;
    /**
     * MySQLi instance
     *
     * @var mysqli
     */
    protected $_mysqli;
    /**
     * The SQL query to be prepared and executed
     *
     * @var string
     */
    protected $_query;
	
	private $stQ;
	
	private $sqlOnly = false;
	
	//The current connected database
	protected $activeCon;
	
	protected $dbConn = NULL;
    /**
     * An array that holds where conditions 'fieldname' => 'value'
     *
     * @var array
     */
	 //The active database
	 protected static $database;
	 
    protected $_where = array();
    /**
     * Dynamic type list for where condition values
     *
     * @var array
     */
    protected $_whereTypeList;
    /**
     * Dynamic type list for table data values
     *
     * @var array
     */
    protected $_paramTypeList;
	
	protected $storage;
	

    /**
     * Dynamic array that holds a combination of where condition/table data value types and parameter referances
     *
     * @var array
     */
    protected $_bindParams = array(''); // Create the empty 0 index

    /**
     * @param string $host
     * @param string $username
     * @param string $password
     * @param string $db
     * @param int $port
     */
    public function __construct($configs = NULL)
    {
	
	
	if($configs ==NULL){
	$configs = $this->getDefaults();
}

      
        
        $this->_mysqli = new Zend_Db_Adapter_Mysqli($configs);
		//$this->getProfiler()->setEnabled(true);
		 $this->_mysqli->getConnection()->autocommit(true);
			$this->activeCon = $this->_mysqli;
        
		
		
		self::$_instance = $this;
		self::$database = new PdoDatabase($configs);
		self::$_instance->storage = new PdoQueryStorage;
    }
		
	public function getConnection(){
	
	return $this->_mysqli;
	}
	
	
	private function getDefaults(){
		$opts = array(
		Zend_Db::ALLOW_SERIALIZATION => true,
		);
		
		$defaults = array(
			'host'=>'localhost',
			'username'=>'root',
			'password'=>NULL,
			'dbname'=>'',
			'port'=>NULL,
			'charset'=>'utf8',
			'options'=>$opts,
			'driver_options'=>NULL,
			'adapterNamespace'=>NULL,
		
		);
		
		return $defaults;
	}

    /**
     * A method of returning the static instance to allow access to the
     * instantiated object from within another class.
     * Inheriting this class would require reloading connection info.
     *
     * @uses $db = MySqliDb::getInstance();
     *
     * @return object Returns the current instance.
     */
    public static function getInstance()
    {
			if(!isset(self::$_instance)){
			$nd = new mspdo;
			
			}
        return self::$_instance;
    }
	
	public function select(){
	return $this->_mysqli->select();
	}
	
	public function table($table){
		
	return new PdoTable($table,$this->_mysqli);
	}
//Get the current connection
public static function getConn(){
return self::$_instance;
}

public function ping(){
	return self::$database->ping();
}
    /**
     * Reset states after an execution
     *
     * @return object Returns the current instance.
     */
    protected function reset()
    {
        $this->_where = array();
        $this->_bindParams = array(''); // Create the empty 0 index
        unset($this->_query);
        unset($this->_whereTypeList);
        unset($this->_paramTypeList);
    }

    /**
     * Pass in a raw query and an array containing the parameters to bind to the prepaird statement.
     *
     * @param string $query      Contains a user-provided query.
     * @param array  $bindParams All variables to bind to the SQL statment.
     *
     * @return array Contains the returned rows from the query.
     */
    public function rawQuery($query, $bindParams = null)
    {
	
       $this->_query = $query;
	   $smt = $this->_mysqli->query($query,$bindParams);
		
			while($row = $smt->fetch()){
				$arr = $row;
				
				array_walk_recursive($arr,'PdoResult_Converter::convert');
				
				$result[] = $arr;
				}
				if(!isset($result)){
						
				$result = $smt->fetchAll();
				}
	return $result;
	}
public function setQuery($q){
  $this->_query = $q;
}
    /**
     *
     * @param string $query   Contains a user-provided select query.
     * @param int    $numRows The number of rows total to return.
     *
     * @return array Contains the returned rows from the query.
     */
    public function query($query, $numRows)
    {
		
       $this->_query = $query;
	   $stmt = $this->_buildQuery($numRows);
	   $qu = new PdoQuery($this,$stmt);
	   $this->reset();
	   
	   
	  return $qu;
    }
	

    /**
     * A convenient SELECT * function.
     *
     * @param string  $tableName The name of the database table to work with.
     * @param integer $numRows   The number of rows total to return.
     *
     * @return array Contains the returned rows from the select query.
     */
    public function get($tableName, $numRows = null)
    {
				
        $this->_query = "SELECT * FROM $tableName";
		
        $stmt = $this->_buildQuery($numRows);
				
		 $smt = new PdoQuery($this,$stmt);
			
		 
		 $this->reset();
			 return $smt;
			 
    }

    /**
     *
     * @param <string $tableName The name of the table.
     * @param array $insertData Data containing information for inserting into the DB.
     *
     * @return boolean Boolean indicating whether the insert query was completed succesfully.
     */
    public function insert($tableName, $insertData)
    {
       $this->_query = "INSERT into $tableName";
	    
	   $smt = $this->_buildQuery(NULL,$insertData);
	   
	   $insert = $this->storage->item->getAdapter()->lastInsertId();
		 $this->reset();
		return $insert;
    }

    /**
     * Update query. Be sure to first call the "where" method.
     *
     * @param string $tableName The name of the database table to work with.
     * @param array  $tableData Array of data to update the desired row.
     *
     * @return boolean
     */
    public function update($tableName, $tableData)
    {
		
        $this->_query = "UPDATE $tableName SET ";

        $stmt = $this->_buildQuery(null, $tableData);
			
		
		 $this->reset();
		return (bool)($this->storage->item->rowCount());
    }
	
	public function switch_query(){
	if($this->sqlOnly === false){
	$this->sqlOnly = true;
	}elseif($this->sqlOnly ===true){
	$this->sqlOnly =false;
	}
	return $this->sqlOnly;
	}

    /**
     * Delete query. Call the "where" method first.
     *
     * @param string  $tableName The name of the database table to work with.
     * @param integer $numRows   The number of rows to delete.
     *
     * @return boolean Indicates success. 0 or 1.
     */
    public function delete($tableName, $numRows = null)
    {
        $this->_query = "DELETE FROM $tableName";

        $stmt = $this->_buildQuery($numRows);
		
		 $this->reset();
		return (bool)($this->storage->item->rowCount());
    }

    /**
     * This method allows you to specify multipl (method chaining optional) WHERE statements for SQL queries.
     *
     * @uses $MySqliDb->where('id', 7)->where('title', 'MyTitle');
     *
     * @param string $whereProp  The name of the database field.
     * @param mixed  $whereValue The value of the database field.
     *
     * @return MysqliDb
     */
    public function where($whereProp, $whereValue)
    {
        $this->_where[$whereProp] = $whereValue;
        return $this;
    }
	public function getBinds(){
	
	return $this->_where;
	}
	
	


    /**
     * This methods returns the ID of the last inserted item
     *
     * @return integer The last inserted item ID.
     */
    public function getInsertId()
    {
        return $this->_mysqli->lastInsertId();
    }

    /**
     * Escape harmful characters which might affect a query.
     *
     * @param string $str The string to escape.
     *
     * @return string The escaped string.
     */
    public function escape($str)
    {
	
        return mysqli_real_escape_string($this->_mysqli->getConnection(),$str);
    }

    /**
     * This method is needed for prepared statements. They require
     * the data type of the field to be bound with "i" s", etc.
     * This function takes the input, determines what type it is,
     * and then updates the param_type.
     *
     * @param mixed $item Input to determine the type.
     *
     * @return string The joined parameter types.
     */
    protected function _determineType($item)
    {
        switch (gettype($item)) {
            case 'NULL':
            case 'string':
                return 's';
                break;

            case 'integer':
                return 'i';
                break;

            case 'blob':
                return 'b';
                break;

            case 'double':
                return 'd';
                break;
        }
        return '';
    }
	
	public function getProfiler(){
		return $this->_mysqli->getProfiler();
	}
	public function lastInsertId(){
		
		return $this->_mysqli->lastInsertId();
	}
    /**
     * Abstraction method that will compile the WHERE statement,
     * any passed update data, and the desired rows.
     * It then builds the SQL query.
     *
     * @param int   $numRows   The number of rows total to return.
     * @param array $tableData Should contain an array of data for updating the database.
     *
     * @return mysqli_stmt Returns the $stmt object.
     */
    protected function _buildQuery($numRows = null, $tableData = null)
    {
        if(strpos($this->_query,'member_groups') !==false){
					//	var_dump($this->_query,$this->_where);
					}
		$this->prepare($numRows,$tableData);
				$binds = $this->_where;
					
				
			 if(!$this->storage->hasItem()){
				
        // Prepare query
			
			
        $stmt = $this->_mysqli->query($this->_query,$this->_bindParams);
			
		$this->storage->commit($stmt);
		$stmt = $this->storage->execute(false,'fetchAll');
		
					
				
			}else{
			
			$stmt = $this->storage->getItem()->item;
				
			
			}
			
			
			
			
			
			/* $stmt = $this->_mysqli->query($this->_query,$this->_bindParams); */
			
        return $stmt;
    }
	
	public function prepare($numRows=NULL,$tableData=null){
	
		$hasTableData = is_array($tableData);
        $hasConditional = !empty($this->_where);

        // Did the user call the "where" method?
        if (!empty($this->_where)) {

            // if update data was passed, filter through and create the SQL query, accordingly.
            if ($hasTableData) {
                $pos = strpos($this->_query, 'UPDATE');
                if ($pos !== false) {
                    foreach ($tableData as $prop => $value) {
                        // determines what data type the item is, for binding purposes.
                        $this->_paramTypeList .= $this->_determineType($value);
							
                        // prepares the reset of the SQL query.
                        $this->_query .= ($prop . ' = ?, ');
						$params[] = $value;
                    }
					
					
                    $this->_query = rtrim($this->_query, ', ');
                }
            }

            //Prepair the where portion of the query
            $this->_query .= ' WHERE ';
            foreach ($this->_where as $column => $value) {
                // Determines what data type the where column is, for binding purposes.
                $this->_whereTypeList .= $this->_determineType($value);

                // Prepares the reset of the SQL query.
				$params[] = $value;
                $this->_query .= ($column . ' = ? AND ');
            }
            $this->_query = rtrim($this->_query, ' AND ');
        }

        // Determine if is INSERT query
        if ($hasTableData) {
            $pos = strpos($this->_query, 'INSERT');

            if ($pos !== false) {
                //is insert statement
                $keys = array_keys($tableData);
                $values = array_values($tableData);
                $num = count($keys);

                // wrap values in quotes
                foreach ($values as $key => $val) {
                    $values[$key] = "'{$val}'";
                    $this->_paramTypeList .= $this->_determineType($val);
					$params[] = $val;
                }

                $this->_query .= '(' . implode($keys, ', ') . ')';
                $this->_query .= ' VALUES(';
                while ($num !== 0) {
                    $this->_query .= '?, ';
                    $num--;
                }
                $this->_query = rtrim($this->_query, ', ');
                $this->_query .= ')';
				
            }
        }

        // Did the user set a limit
        if (isset($numRows)) {
            $this->_query .= ' LIMIT ' . (int)$numRows;
        }
		
		$this->_bindParams = $params;
			
		$this->storage->bucket($this->_query,$this->_bindParams);
		
			
		return $this->_query;
	}

   
	
    /**
     * Method attempts to prepare the SQL query
     * and throws an error if there was a problem.
     *
     * @return mysqli_stmt
     */
    protected function _prepareQuery()
    {
		
				
         /*  if (!$stmt = $this->_mysqli->prepare($this->_query)) {
            $this->databaseError("Problem preparing query ($this->_query) " . $this->_mysqli->error, E_USER_ERROR);
        } */
		$this->stQ = $this->_query;
		
        return $stmt;
    }

	public function createDatabase($database) {
	
	}
	/**
	 * Drop the database that this object is currently connected to.
	 * Use with caution.
	 */
	public function dropDatabase() {
		$this->dropDatabaseByName($this->database);
	}
		/**
	 * Drop the database that this object is currently connected to.
	 * Use with caution.
	 */
	public function dropDatabaseByName($dbName) {
		$this->query("DROP DATABASE `$dbName` ");
	}
	
	public function getSql(){
	return $this->stQ;
	}
	/**
	 * Returns  currently selected database
	 */
	public function currentDatabase() {
		return self::$database;
	}
		
	
		/**
	 * Returns a column
	 */
	public function allDatabaseNames() {
		$s = $this->query("SHOW DATABASES")->fetchHide();
		
		return $s;
	}
	/**
	 * Create a new table.
	 * @param $tableName The name of the table
	 * @param $fields A map of field names to field types
	 * @param $indexes A map of indexes
	 * @param $options An map of additional options.  The available keys are as follows:
	 *   - 'MSSQLDatabase'/'MySQLDatabase'/'PostgreSQLDatabase' - database-specific options such as "engine" for MySQL.
	 *   - 'temporary' - If true, then a temporary table will be created
	 * @return The table name generated.  This may be different from the table name, for example with temporary tables.
	 $sql->createTable('person',array('name'=>'VARCHAR(255)','title'=>'CHAR(15)','email'=>'CHAR(15)'),array('email'=>'UNIQUE') )
	 */
	public function createTable($table, $fields = null, $indexes = null, $options = null, $advancedOptions = null) {
		self::$database->createTable($table,$fields,$indexes,$options,$advancedOptions);
	}
	/**
	 * Alter a table's schema.
	 * @param $table The name of the table to alter
	 * @param $newFields New fields, a map of field name => field schema
	 * @param $newIndexes New indexes, a map of index name => index type
	 * @param $alteredFields Updated fields, a map of field name => field schema
	 * @param $alteredIndexes Updated indexes, a map of index name => index type
	 * @param $alteredOptions
	 */

	public function isView($tableName) {
		$info = $this->query("SHOW /*!50002 FULL*/ TABLES LIKE '$tableName'")->fetch();
		
		return $info && strtoupper($info['Table_type']) == 'VIEW';
	}
	
	public function renameTable($oldTableName, $newTableName) {
	

	if(strpos($newTableName,$this->prefix,0) === false){
	$newTableName = $this->prefix.$newTableName;
	}elseif(strpos($newTableName,$this->prefix,0) !=0){
	$newTableName = $this->prefix.$newTableName;
	}
	
	if($this->tableExists($oldTableName))
		return $this->query("ALTER TABLE $oldTableName RENAME $newTableName")->rowCount();
	}
	/**
	 * Checks a table's integrity and repairs it if necessary.
	 * @var string $tableName The name of the table.
	 * @return boolean Return true if the table has integrity after the method is complete.
	 */
	public function checkAndRepairTable($tableName) {
		if(!$this->runTableCheckCommand("CHECK TABLE `$tableName`")) {
			if($this->runTableCheckCommand("CHECK TABLE `".strtolower($tableName)."` ")){
			
				return $this->renameTable(strtolower($tableName),$tableName);
			}

			
			return $this->runTableCheckCommand("REPAIR TABLE `$tableName` USE_FRM");
		} else {
			return true;
		}
	}
		/**
	 * Helper function used by checkAndRepairTable.
	 * @param string $sql Query to run.
	 * @return boolean Returns if the query returns a successful result.
	 */
	protected function runTableCheckCommand($sql) {
		$testResults = $this->query($sql)->fetchAll();
		foreach($testResults as $testRecord) {
			if(strtolower($testRecord['Msg_text']) != 'ok') {
				return false;
			}
		}
		return true;
	}
		/**
	 * Change the database column name of the given field.
	 *
	 * @param string $tableName The name of the tbale the field is in.
	 * @param string $oldName The name of the field to change.
	 * @param string $newName The new name of the field
	 */
	public function renameField($tableName, $oldName, $newName) {
		$fieldList = $this->fieldList($tableName);
		if(array_key_exists($oldName, $fieldList)) {
			$this->query("ALTER TABLE \"$tableName\" CHANGE \"$oldName\" \"$newName\" " . $fieldList[$oldName]);
		}
	}
	private static $_cache_collation_info = array();
	
	public function fieldList($table) {
		$fields = $this->rawQuery("SHOW FULL FIELDS IN `$table`");
		
		foreach($fields as $field) {

			// ensure that '' is converted to \' in field specification (mostly for the benefit of ENUM values)
			$fieldSpec = str_replace('\'\'', '\\\'', $field['Type']);
			if(!$field['Null'] || $field['Null'] == 'NO') {
				$fieldSpec .= ' not null';
			}

			if($field['Collation'] && $field['Collation'] != 'NULL') {
				// Cache collation info to cut down on database traffic
				if(!isset(self::$_cache_collation_info[$field['Collation']])) {
					self::$_cache_collation_info[$field['Collation']]
						= $this->query("SHOW COLLATION LIKE '$field[Collation]'")->fetch();
				}
				$collInfo = self::$_cache_collation_info[$field['Collation']];
				$fieldSpec .= " character set $collInfo[Charset] collate $field[Collation]";
			}

			if($field['Default'] || $field['Default'] === "0") {
				if(is_numeric($field['Default']))
					$fieldSpec .= " default " . Convert::raw2sql($field['Default']);
				else
					$fieldSpec .= " default '" . Convert::raw2sql($field['Default']) . "'";
			}
			if($field['Extra']) $fieldSpec .= " $field[Extra]";

			$fieldList[$field['Field']] = $fieldSpec;
		}
		return $fieldList;
	}
	/**
	 * This takes the index spec which has been provided by a class (ie static $indexes = blah blah)
	 * and turns it into a proper string.
	 * Some indexes may be arrays, such as fulltext and unique indexes, and this allows database-specific
	 * arrays to be created. See {@link requireTable()} for details on the index format.
	 *
	 * @see http://dev.mysql.com/doc/refman/5.0/en/create-index.html
	 *
	 * @param string|array $indexSpec
	 * @return string MySQL compatible ALTER TABLE syntax
	 */
	public function convertIndexSpec($indexSpec){
		if(is_array($indexSpec)){
			//Here we create a db-specific version of whatever index we need to create.
			switch($indexSpec['type']){
				case 'fulltext':
					$indexSpec='fulltext (' . str_replace(' ', '', $indexSpec['value']) . ')';
					break;
				case 'unique':
					$indexSpec='unique (' . $indexSpec['value'] . ')';
					break;
				case 'btree':
				case 'index':
					$indexSpec='using btree (' . $indexSpec['value'] . ')';
					break;
				case 'hash':
					$indexSpec='using hash (' . $indexSpec['value'] . ')';
					break;
			}
		}

		return $indexSpec;
	}
	/**
	 * @param string $indexName
	 * @param string|array $indexSpec See {@link requireTable()} for details
	 * @return string MySQL compatible ALTER TABLE syntax
	 */
	protected function getIndexSqlDefinition($indexName, $indexSpec=null) {

		$indexSpec=$this->convertIndexSpec($indexSpec);

		$indexSpec = trim($indexSpec);
		if($indexSpec[0] != '(') list($indexType, $indexFields) = explode(' ',$indexSpec,2);
		else $indexFields = $indexSpec;

		if(!isset($indexType))
			$indexType = "index";

		if($indexType=='using')
			return "index \"$indexName\" using $indexFields";
		else {
			return "$indexType $indexName $indexFields";
		}

	}
	/**
	 * MySQL does not need any transformations done on the index that's created, so we can just return it as-is
	 */
	public function getDbSqlDefinition($tableName, $indexName, $indexSpec){
		return $indexName;
	}
		/**
	 * Alter an index on a table.
	 * @param string $tableName The name of the table.
	 * @param string $indexName The name of the index.
	 * @param string $indexSpec The specification of the index, see {@link SS_Database::requireIndex()}
	 *                          for more details.
	 */
	public function alterIndex($tableName, $indexName, $indexSpec) {

		$indexSpec=$this->convertIndexSpec($indexSpec);

		$indexSpec = trim($indexSpec);
		if($indexSpec[0] != '(') {
			list($indexType, $indexFields) = explode(' ',$indexSpec,2);
		} else {
			$indexFields = $indexSpec;
		}

		if(!$indexType) {
			$indexType = "index";
		}

		$this->query("ALTER TABLE \"$tableName\" DROP INDEX \"$indexName\"");
		$this->query("ALTER TABLE \"$tableName\" ADD $indexType \"$indexName\" $indexFields");
	}
	/**
	 * Return the list of indexes in a table.
	 * @param string $table The table name.
	 * @return array
	 */
	public function indexList($table) {
		
	}
	/**
	 * Returns a list of all the tables in the database.
	 * @return array
	 */
	public function tableList() {
	$tables = self::$database->listTable();
		return $tables;
	}
	public function tableExists($table){
	if(in_array($table,$this->tableList()))return true;else return false;
	}
		/**
	 * Return the number of rows affected by the previous operation.
	 * @return int
	 */
	public function affectedRows() {
		return $this->rowCount();
	}
	public function databaseError($msg, $errorLevel = E_USER_ERROR) {
		// try to extract and format query
				
		if(preg_match('/Couldn\'t run query: ([^\|]*)\|\s*(.*)/', $msg, $matches)) {
			$formatter = new SQLFormatter();
			$msg = "Couldn't run query: \n" . $formatter->formatPlain($matches[1]) . "\n\n" . $matches[2];
		}

		user_error($msg, $errorLevel);
	}
	

	/**
	 * Returns true if the given table is exists in the current database
	 * NOTE: Experimental; introduced for db-abstraction and may changed before 2.4 is released.
	 */
	public function hasTable($table) {
		$SQL_table = Convert::raw2sql($table);
		return (bool)($this->query("SHOW TABLES LIKE '$SQL_table'")->value());
	}
/**
	 * Returns a SQL fragment for querying a fulltext search index
	 * @param $fields array The list of field names to search on
	 * @param $keywords string The search query
	 * @param $booleanSearch A MySQL-specific flag to switch to boolean search
	 */
	public function fullTextSearchSQL($fields, $keywords, $booleanSearch = false) {
		$boolean = $booleanSearch ? "IN BOOLEAN MODE" : "";
		$fieldNames = '"' . implode('", "', $fields) . '"';

		$SQL_keywords = Convert::raw2sql($keywords);
		$SQL_htmlEntityKeywords = Convert::raw2sql(htmlentities($keywords, ENT_NOQUOTES, 'UTF-8'));

		return "(MATCH ($fieldNames) AGAINST ('$SQL_keywords' $boolean) + MATCH ($fieldNames)"
			. " AGAINST ('$SQL_htmlEntityKeywords' $boolean))";
	}

    /**
     * Close connection
     */
    public function __destruct()
    {
	if(is_object($this->dbConn)){
        @$this->_mysqli->close();
		}
    }

	public function close(){
	self::$database->close();
	}
    /**
     * @param array $arr
     *
     * @return array
     */
    protected function refValues($arr)
    {
        //Reference is required for PHP 5.3+
        if (strnatcmp(phpversion(), '5.3') >= 0) {
            $refs = array();
            foreach ($arr as $key => $value) {
                $refs[$key] = & $arr[$key];
            }
            return $refs;
        }
        return $arr;
    }

} // END class

class PdoQueryStorage extends MsPdo{
		
		protected $bucket;
		protected $item;
		private $token;
		private $store_Object;
	public function __construct(){
	if(!isset($this->token)){
		$config = parent::getInstance()->_mysqli->getConfig();
		$this->token = __CLASS__.$config["dbname"];
		$this->store_Object = new ArrayObject(array());
		$this->store_Object->setFlags(ArrayObject::ARRAY_AS_PROPS);
		}
		
		if(Registry::getInstance()->isRegistered($this->token) ==false){
	Registry::getInstance()->set($this->token,$this->token);
		
		
		
		}
	}
	//Open a new storage bucket
	public function bucket($query,$params){
		$cmd = $query;
		
			if(!empty($params) and !empty($cmd)){
				$cmd = $cmd.strlen($cmd).json_encode($params);
			}
				
				if(isset($cmd) and !empty($cmd)){
				$this->bucket = $cmd;
				$annot = array(
			'commitment'=>$this->bucket,//Commeitment worker
			'cmd'=>NUll,//Commad to run inside the commitment
			'argument'=>null,//Optional argument for the commitment
			'key'=>$cmd,
		);
			$this->bucket = new ArrayObject($annot,ArrayObject::ARRAY_AS_PROPS);
		
				}
			
	}
	//Clear previously opened storage bucket
	public function rollBack(){
		unset($this->bucket);
	}
	//Check if bucket contained has an item
	public function hasItem(){
		
		return $this->store_Object->offsetExists($this->bucket->key);
		
	}
	//Execute the item inside the bucket
	public function execute($return=true,$cmd=NULL){
			if($cmd){
				$this->store_Object->offsetGet($this->bucket->key)->cmd = $cmd;
			}
		if(isset($this->bucket)){
		$file = $this->store_Object->offsetGet($this->bucket->key);
		
			if($return)
		return($file->item);
		}
		
		//Check if commeitment can be called
		
			if(!empty($file->cmd) and method_exists($file->item,$file->cmd)){
					
						try {
						$arg;
						if(isset($file->argument) and !empty($file->argument)){
						$arg = $file->argument;
						}
						
    $run = $file->item->{$file->cmd}($arg);
	
    return $run;
} catch (Exception $e) {
   throw new ErrorException($e->getMessage());
	return false;
} catch (Zend_Exception $e) {
return false;
    // perhaps factory() failed to load the specified Adapter class
}
			}else{
				return ($file->item);
			}
	}
	
	//Coming changes to priously opened stoare bukcet
	public function commit($commitment){
		$this->item = $commitment;
		
		$this->setStorage();
	}
	
	public function getItem(){
		$file = $this->store_Object->offsetGet($this->bucket->key);
		return $file;
	}
	
	protected function setStorage(){
			$sm = $this->bucket;
			$sm->item = $this->item;
			
		$this->store_Object->offsetSet($sm->key,$sm);
	}
	
}
class PdoDatabase extends msPdo{

	public function __construct(){
		
	}

	public function ping(){
		try {
    $db = $this->getConnection;
    return true;
} catch (Zend_Db_Adapter_Exception $e) {
    // perhaps a failed login credential, or perhaps the RDBMS is not running
	return false;
} catch (Zend_Exception $e) {
return false;
    // perhaps factory() failed to load the specified Adapter class
}
	}
	public function getConnection(){
		return parent::getInstance()->_mysqli->getConnection();
	}
	public function listTable(){
		return parent::getInstance()->_mysqli->listTables();
	}
	
	public function indexList($table){
		$indexes = parent::getInstance()->query("SHOW INDEXES IN `$table` ")->fetch();
		
		$groupedIndexes = array();
		$indexList = array();

		foreach($indexes as $index) {
			$groupedIndexes[$index['Key_name']]['fields'][$index['Seq_in_index']] = $index['Column_name'];

			if($index['Index_type'] == 'FULLTEXT') {
				$groupedIndexes[$index['Key_name']]['type'] = 'fulltext ';
			} else if(!$index['Non_unique']) {
				$groupedIndexes[$index['Key_name']]['type'] = 'unique ';
			} else if($index['Index_type'] =='HASH') {
				$groupedIndexes[$index['Key_name']]['type'] = 'hash ';
			} else if($index['Index_type'] =='RTREE') {
				$groupedIndexes[$index['Key_name']]['type'] = 'rtree ';
			} else {
				$groupedIndexes[$index['Key_name']]['type'] = '';
			}
		}

		if($groupedIndexes) {
			foreach($groupedIndexes as $index => $details) {
				ksort($details['fields']);
				$indexList[$index] = $details['type'] . '("' . implode('","',$details['fields']) . '")';
			}
		}

		return $indexList;
	}
	
		public function createDatabase($database) {
			if(empty($database))return false;
		$sql = "CREATE DATABASE `$database` DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci";
		$query = new Zend_Db_Statement_Mysqli(parent::getInstance()->_mysqli,$sql);
		return $query->execute();

	}
	public function describeTabe($tableName){
		return parent::getInstance()->_mysqli->describeTable($tableName);
	}
	//Close the table transaction token
	public function close(){
		parent::getInstance()->_mysqli->closeConnection();
	}
	
	public function selectDatabase(){
		
	}
	public function hasTable($table){
	$SQL_table = $table;
	
	$query = parent::getInstance()->query("SHOW TABLES LIKE '$SQL_table' ");
	return (bool)($query->fetch());
		
	}
	
	public function createTable($table, $fields = null, $indexes = null, $options = null, $advancedOptions = null){
	$fieldSchemas = $indexSchemas = "";
		
		if(!empty($options[get_class($this)])) {
			$addOptions = $options[get_class($this)];
		} elseif(!empty($options[get_parent_class($this)])) {
			$addOptions = $options[get_parent_class($this)];
		} else {
			$addOptions = "ENGINE=InnoDB";
		}
		$table = Config::get()->Dbprefix.$table;
		if(!isset($fields['ID']) AND !isset($fields['id'])) $fields['id'] = "int(245) not null auto_increment";
		if($fields) foreach($fields as $k => $v) $fieldSchemas .= "$k $v,\n";
		if($indexes) foreach($indexes as $k => $v){if(strpbrk($k,'(')===false) 
		$k="($k)"; $indexSchemas .= parent::getIndexSqlDefinition($k, $v);
		}
$table = strip_tags($table);
		// Switch to "CREATE TEMPORARY TABLE" for temporary tables
		$temporary = empty($options['temporary']) ? "" : "TEMPORARY";
		
if($this->hasTable($table) == false){
$sql = "CREATE $temporary TABLE $table (
				$fieldSchemas
				$indexSchemas,
				primary key (id)
			) {$addOptions}";
			
$query = new Zend_Db_Statement_Mysqli(parent::getInstance()->_mysqli,$sql);
		return $query->execute();
			
		}else $table =NULL;
		return false;
	}
	
}
	class PdoTable extends Zend_Db_Table_Abstract{
	
			protected $table;
			protected $_name;
			protected $_sequence;
			protected $_primary;
			protected $_rowClass;
			//protected $_rowsetClass;
			
		
			public function __construct($table,$adapter){
			$this->_name = $table;
			 parent::_setupTableName();
			 $configs = array(
			 'db'=>$adapter,
			 'name'=>$this->_name,
			 );
			 
			parent::setDefaultAdapter($adapter);
			parent::_setupDatabaseAdapter($adapter);
			$this->table = new Zend_Db_Table($configs);
			parent::setRowClass('PdoRow_Row_Abstract');
			//parent::setRowSetClass('PdoRow_Rowset_Abstract');
			return $this->table;
			}
			
			public function init(){
				
			}
			public function find($what){
			
				return parent::find($what);
			}
			
			
			
			public function select(){
				return parent::select();
			}
			public function __call($method,$arg){
				
			}
			
	}
	
	class PdoRow_RowSet_Abstract extends Zend_Db_Table_Rowset_abstract{
		
	}
	class PdoRow_Row_Abstract extends Zend_Db_Table_Row{
	
		 protected $_dataTypes = array(
                'bit' => 'int',
                'tinyint' => 'int',
                'bool' => 'bool',
                'boolean' => 'bool',
                'smallint' => 'int',
                'mediumint' => 'int',
                'int' => 'int',
                'integer' => 'int',
                'bigint' => 'float',
                'serial' => 'int',
                'float' => 'float',
                'real' => 'float',
                'numeric' => 'float',
                'money' => 'float',
                'double' => 'float',
                'double precision' => 'float',
                'decimal' => 'float',
                'dec' => 'float',
                'fixed' => 'float',
                'year' => 'int'
        );
        
        /**
         * Initialize object
         *
         * Called from {@link __construct()} as final step of object instantiation.
         *
         * @return void
         */
        public function init() {
                $table = $this->getTable();
				
                if ($table) {
                        $cols = $table->info(Zend_Db_Table_Abstract::METADATA);
						
                        foreach ($cols as $name => $col) {
                                $dataType = strtolower($col['DATA_TYPE']);
								
                                if (array_key_exists($dataType, $this->_dataTypes)) {
							
                                        settype($this->_data[$name], $this->_dataTypes[$dataType]);
                                }
                        }
                }
        }
	
	}
	class PdoResult_Converter{
	
		public function convert(&$value,$key){
				
			if(is_string($value)){
					if(is_numeric($value) AND strlen($value) < 10){
						
				$value = (int)$value;
				}
			}
		}
	
	}
class PdoQuery extends MsPdo {
	/**
	 * The MySQLDatabase object that created this result set.
	 * @var MySQLDatabase
	 */
	protected $transaction;

	/**
	 * The internal MySQL handle that points to the result set.
	 * @var resource
	 */
	protected $handle;
	
	protected $isExportable;

	/**
	 * Hook the result-set given into a Query class, suitable for use by SilverStripe.
	 * @param database The database object that created this query.
	 * @param handle the internal mysql handle that is points to the resultset.
	 */
	public function __construct(MsPdo $database, $handle) {
		$this->transaction = $database;
		$this->handle = $handle;
		$this->isExportable = $handle instanceof Zend_Db_Statement_Mysqli;
		
	}

	public function __destruct() {
		/* if(is_object($this->handle)) $this->handle->free(); */
	}
	
	public function fetch(){
		
			if($this->isExportable  ===false)return $this->handle;
		return $this->handle->fetch();
	}
	
	public function seek($row) {
		if(is_object($this->handle)) return $this->handle->data_seek($row);
	}
	
	public function numRecords() {
		if(is_object($this->handle)) return $this->handle->num_rows;
	}

	public function nextRecord(){
		if(is_object($this->handle) && ($data = $this->handle->fetch_assoc())) {
			return $data;
		} else {
			return false;
		}
	}
	
	
	public function fetchAll(){
		if($this->isExportable  ===false)return $this->handle;
			
	while($row = $this->handle->fetch()){
				$arr = $row;
				array_walk_recursive($arr,'PdoResult_Converter::convert');
				$result[] = $arr;
				}
				if(!isset($result)){
				$result = $this->handle->fetchAll();
				}

		return $result;
	}
	
	public function fetchAssoc(){
		$query = $this->transaction->_query;
		if($this->isExportable  ===false)return $this->handle;
		$arr = $this->handle->fetchall(Zend_Db::FETCH_ASSOC);
	array_walk_recursive($arr,'PdoResult_Converter::convert');
	
		return $arr;
	}
	
	public function fetchObject(){
	if($this->isExportable  ===false)return $this->handle;
		$query = $this->transaction->_query;
	$ref = array_values($this->transaction->_where);
	
		return $this->handle->fetchall(Zend_Db::FETCH_OBJ);
	}
	
	public function fetchColumn($col=NULL){
		
	if($this->isExportable  ===false)return $this->handle;
			$query = $this->transaction->_query;
	$arr = $this->handle->fetchColumn($col);
	array_walk_recursive($arr,'PdoResult_Converter::convert');
		return $arr;
	}
	
	public function fetchHide(){
	if($this->isExportable  ===false)return $this->handle;
		$query = $this->transaction->_query;
	$ref = array_values($this->transaction->_where);
	
		return $this->handle->fetchall(Zend_Db::FETCH_NUM);
	}
	
	
	
}