<?php 
defined('SAFE')or die('Not allowed');

//Used to manage global variables
class Registry extends arrayObject{

 private static $_registry = null;
 
    
    private static $_registryClassName = 'Registry';

 protected function init()
    {
        self::setInstance(new self::$_registryClassName());
    }
	
	   public static function setInstance(Registry $registry)
    {
        if (self::$_registry !== null) {
            
            throw new invalidArgumentException('Registry is already initialized');
        }

        self::setClassName(get_class($registry));
        self::$_registry = $registry;
    }
	   /**
     * Retrieves the default registry instance.
     *
     * @return Zend_Registry
     */
    public static function getInstance()
    {
        if (self::$_registry === null) {
            self::init();
        }

        return self::$_registry;
    }
	//Set the classname to use for default instance
	  public static function setClassName($registryClassName = 'Registry')
    {
        if (self::$_registry !== null) {
            
            throw new invalidArgumentException('Registry is already initialized');
        }

        if (!is_string($registryClassName)) {
          
            throw new invalidArgumentException("Argument is not a class name");
        }

       
        if (!class_exists($registryClassName)) {
            require_once ZEND.'Loader.php';
            Zend_Loader::loadClass($registryClassName);
        }

        self::$_registryClassName = $registryClassName;
    }
	
	 public static function _unsetInstance()
    {
        self::$_registry = null;
    }
	   public static function get($index)
    {
        $instance = self::getInstance();


        if (!$instance->offsetExists($index)) {
            
            throw new invalidArgumentException("No entry is registered for key '$index'");
        }

        return $instance->offsetGet($index);
    }
	 public static function set($index, $value)
    {
		
        $instance = self::getInstance();
	/* 	if($instance->isRegistered($index) and is_array($instance->get($index)) and !ArrayLib::is_associative($instance->get($index))){
		$ar = $instance->get($index);
		if(count($ar)>0){
		$ar[] = $value[0];
		$value = $ar;
	}
		} */
		
        $instance->offsetSet($index, $value);
		
    }
	  public static function isRegistered($index)
    {
        if (self::$_registry === null) {
            return false;
        }
        return self::$_registry->offsetExists($index);
    }
	  public function __construct($array = array(), $flags = parent::ARRAY_AS_PROPS)
    {
        parent::__construct($array, $flags);
    }
	  public function offsetExists($index)
    {
        return array_key_exists($index, $this);
    }
	
	public function __call($method,$args){
		if(method_exists(self::getInstance(),$method)){
			return call_user_func_array(array(self::getInstance(),$method),$args);
		}
	}

}





?>