<?php
define('POS',true);
define('SAFE',true);
define('BASE',__DIR__);
define('ZEND',BASE.'/libs/Zend/');
define('LIBS',BASE.'/libs/');
define('DELIMITER_DIR','/');
define('DELIMITER_UNDER','_');

$paths = array(
ZEND,
LIBS
);
set_include_path(
implode(PATH_SEPARATOR,$paths)
);
function autoload($class){
		if(file_exists(LIBS.$class.'.php')){
	include_once(BASE.'/libs/'.$class.'.php');
		}elseif(($e=BASE.'/libs/'.strtolower($class).'.php') && file_exists($e)){
			include_once($e);
		}elseif(file_exists(ZEND.$class.'.php')){
			include_once(ZEND.$class.'.php');
		}
}
spl_autoload_register('autoload');
error_reporting(0);
date_default_timezone_set('Africa/Lagos');
$menu = array(
'cart'=>'Cart',
'sales'=>'Sales',
'inventory'=>'Stationeries',
'setup'=>'Application setup',
);

session_start();
	if(empty($_SESSION['user'])){
		header("Location: auth.php");
		exit;
	}
$current_page = end(explode('/',parse_url($_SERVER['REQUEST_URI'].'.php',PHP_URL_PATH)));
$ext = pathinfo($current_page,PATHINFO_EXTENSION);
$current_page = strtolower(basename($current_page,'.'.$ext));
$xconfig = parse_ini_file(__DIR__.'/db.ini');

new registry;
$db = new mspdo($xconfig);
$cf = $db->rawquery('select * from setup limit 1');
$cf = current($cf);
if($_SERVER['REQUEST_METHOD']=='POST' AND isset($_REQUEST['t'])){
		$t = $_REQUEST['t'];
			switch($t){
				case 'trash':
				$db->where('id',$_GET['q'])->delete('stocks');
				$db->getConnection()->commit();
				die(1);
				break;
				case 'add':
				$d = $_POST;
				$id = $db->insert('stocks',$d);
				$db->getConnection()->commit();
				die(''.$id.'');
				break;
				case 'edit':
				$d = $_POST;
				$db->where('id',$_GET['q'])->update('stocks',$d);
				$db->getConnection()->commit();
				break;
				case 'on':
				case 'off':
					$s = 1;
					if($t=='off'){
						$s = 0;
					}
					$db->where('id',$_GET['q'])->update('stocks',array('state'=>$s));
					$db->getConnection()->commit();
				break;
				case 'pos':
				$d = $_POST;
				$t = count($d['items']);
				$sql = array();$crt = date('Y-m-d H:i:s');
				$sn = strtotime($crt);
				$data = array();
				for($i=0;$t > $i;$i++){
					$g = $db->rawquery('select name,quantity as q,state,min_price from stocks where id='.$d['items'][$i]['ref'].'');
					$qt = ($g[0]['q']-$d['items'][$i]['quantity']);
					$d['items'][$i]['total'] = ($g[0]['min_price'] * $d['items'][$i]['quantity']);
					$data[]= array('product'=>$g[0]['name'],'date'=>$crt,'quantity'=>$d['items'][$i]['quantity'],'cost'=>number_format($d['items'][$i]['total']),'price'=>number_format($g[0]['min_price'])); 
					
					$sql[] = "(".$d['items'][$i]['ref'].",'".$d['items'][$i]['quantity']."','".$crt."','".$d['items'][$i]['total']."','".$sn."')";
					$st = 'quantity='.$qt;
						if($qt < 1 && $g[0]['state'] ==true){
							$st .=',state=0';
						}
					$db->rawquery('UPDATE stocks SET '.$st.' where id='.$d['items'][$i]['ref']);
				}
					if(!empty($sql)){
						$db->rawquery('insert into sales (product,quantity,date,cost,sn) VALUES '.implode(',',$sql).'');
					}
					$db->getConnection()->commit();
					$dta = array('list'=>$data,'sn'=>$sn);
					die(json_encode($dta));
				break;
				case 'rece':
				$g = $db->rawquery('select sl.quantity,sl.date,sl.cost,st.name as product,st.min_price as price from sales as sl left join stocks as st on sl.product=st.id where sn=?',array($_GET['q']));
				
				die(json_encode($g));
				break;
				case 'delrece':
				$db->rawquery('delete from sales where sn=?',array($_GET['q']));
				$db->getConnection()->commit();
				break;
				case 'setup':
				$d = $_POST;
				unset($d['t']);
					if(!empty($_FILES)){
				$f = new file($_FILES['file']['tmp_name']);
				$ext = pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
				$ext = strtolower($ext);
				$i = $f->moveUploaded(BASE.'/assets/img/logo.'.$ext);
					if($i){
						$d['logo'] = 'logo.'.$ext;
						}
					}
					
					if($cf){
						$db->where('id',$cf['id'])->update('setup',$d);
					}else{
						$db->insert('setup',$d);
					}
					$db->getConnection()->commit();
					header('Location: '.utilphp::get_current_url());
				break;
			}
			die;
	}
if(empty($cf) AND $current_page !=='setup'){
	header('Location: /setup');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>POS Application</title>
    <meta charset="utf-8">
    <meta content="ie=edge" http-equiv="x-ua-compatible">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link href="favicon.png" rel="shortcut icon">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet" type="text/css">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/normalize.css" rel="stylesheet">
    <link href="assets/css/main.css?version=3.4" rel="stylesheet">
   
  </head>
  <body>
    <div class="all-wrapper menu-side">
      <div class="layout-w">
          <div class="desktop-menu menu-side-compact-w menu-activated-on-hover color-scheme-light">
          
         
        </div>
        <div class="content-w">
          <div class="top-menu-secondary">
            <ul>
				<?php
					foreach($menu as $name => $title){
							$attr = '';
							if($name ===$current_page){
								$attr = 'class="active"';
							}
						echo '<li '.$attr.'>
                <a href="'.$name.'">'.$title.'</a>
              </li>';
					}
				
				?>
            </ul>
            <div class="top-menu-controls">
				<a class="btn btn-danger" href="/auth.php">Sign out <span class="fa fa-remove"></span></a>
              <div class="top-icon top-search hidden-xl-up">
                <i class="os-icon os-icon-ui-37"></i>
              </div>
            
             
             
             
            </div>
          </div>
          <div class="content-i">
				<?php
					if(file_exists(__DIR__.'/pages/'.$current_page.'.php')){
						include(__DIR__.'/pages/'.$current_page.'.php');
					}
				?>
          </div>
        </div>
      </div>
      <div class="display-type"></div>
    </div>
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap/modal.js"></script>
	<script src="assets/js/mdialog.js"></script>
	<script src="assets/js/bootstrap/util.js"></script>
	<script src="assets/js/chart.min.js"></script>
	<script src="assets/js/printthis.js"></script>
	<script src="assets/js/main.js"></script>
  </body>
</html>