Steps to Installation

1 -  Import the db.sql file into your database
2 - Open the db.ini file and enter your database information respectively 
3 - Open the domain name where your app is installed and proceed with configuring your details
4 - Fill your your products by following the "Stationaries" link
5 - Done