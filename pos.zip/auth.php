<?php
session_start();

$usr = parse_ini_file(__DIR__.'/user.ini',true);
	if($_SERVER['REQUEST_METHOD']=='POST' && $_POST['task']=='login'){
		$n = $_POST['username'];
		$p = $_POST['password'];
			if(array_key_exists($n,$usr) && $usr[$n]['pass']== $p){
				$_SESSION['user'] = $n;
				header("Location: /cart");
			}
		die;
	}
	unset($_SESSION['user']);
?>
<!DOCTYPE html>
<html>
  <head>
    <title>POS Application</title>
    <meta charset="utf-8">
    <meta content="ie=edge" http-equiv="x-ua-compatible">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link href="favicon.png" rel="shortcut icon">
    <link href="assets/css/normalize.css" rel="stylesheet">
    <link href="assets/css/main.css?version=3.4" rel="stylesheet">
   
  </head>
  <body>
	 <div class="all-wrapper menu-side with-pattern">
      <div class="auth-box-w">
			<form method="POST">
		<div class="form-group" data-tie-group="register">
            <label for="">Name</label><input class="form-control" name="username" placeholder="Enter your name" type="text">
            <div class="pre-icon os-icon os-icon-user-male-circle2"></div>
          </div>
          
          <div class="form-group" data-tie-group="register,login">
            <label for="">Password</label><input required name="password" class="form-control" placeholder="Enter your password" type="password">
            <div class="pre-icon os-icon os-icon-fingerprint"></div>
          </div>
		  
		  
		  <input type="hidden" name="task" value="login" />
		  <button type="submit" class="btn btn-success">Login</button>
        </form>
	  </div>
	  </div>
  </body>
  </html>