<?php
defined('POS') or die;
	$stocks = $db->rawquery('select * from stocks');
?>

<div class="row p-0" id="inventory_page">
	<div class="col-10 p-5 offset-1">
		<div class="element-wrapper">
		
			<div class="element-header">
				<h6>Stationeries</h6>
				<button id="add_pro" class="btn btn-outline-primary float-right"><span class="fa fa-plus"></span></button>
			</div>
			<div class="form-group">
			<input placeholder="Start Typing.." id="search_item" class="mac form-control" />
			</div>
			<div class="element-box">
				<div>
					<table class="table">
						<thead>
							<tr>
								<td>Product</td>
								<td>Code</td>
								<td>Quantity</td>
								<td>Supplier</td>
								<td class="p-0">Purchase date</td>
								<td>Cost Price</td>
								<td>Selling Price</td>
								<td class="p-0">Availabe</td>
								<td></td>
							</tr>
						</thead>
						<tbody>
							<?php 
							$stkl =  array();
								if(!empty($stocks)){
									$t = count($stocks);
									for($i=0;$t > $i;$i++){
										$stkl[$stocks[$i]['id']] = $stocks[$i];
										echo '<tr data-id="'.$stocks[$i]['id'].'">';
										$state = 'Yes';$stb = 'text-success';
										if($stocks[$i]['state'] !=true){
											$state = 'No';$stb = 'text-danger';
										}
											echo '<td><strong>'.$stocks[$i]['name'].'</strong></td>
								<td><span class="text-danger">'.$stocks[$i]['code'].'</span></td>
								<td><strong>'.$stocks[$i]['quantity'].'</strong></td>
								<td>'.$stocks[$i]['supplier'].'</td>
								<td>'.date('d/m/Y',strtotime($stocks[$i]['stock_date'])).'</td>
								<td><strong class="text-primary">'.$stocks[$i]['stock_price'].'</strong></td>
								<td><strong class="text-primary">'.$stocks[$i]['min_price'].'</strong></td>
								<td class="p-0"><strong class="'.$stb.'">'.$state.'</strong></td>
								<td>
								<button role="edit" title="Edit" class="btn btn-outline-primary btn-sm"><span class="fa fa-edit"></span></button>
								<button role="off" title="Set product Unavailable" class="btn btn-outline-danger btn-sm"><span class="fa fa-ban"></span></button>
								<button role="on" title="Set product available" class="btn btn-outline-success btn-sm"><span class="fa fa-check"></span></button>
								<button class="btn btn-info btn-sm ml-2" role="copy" title="Duplicate item"><span class="fa fa-clone"></span></button>
								<button class="btn btn-danger btn-sm ml-2" role="trash" title="Trash item"><span class="fa fa-trash"></span></button>
								</td>';
										echo '</tr>';
									}
								}
							?>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	<?php echo 'stocks='.json_encode($stkl).';'; ?>
</script>