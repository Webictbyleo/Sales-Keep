<?php
defined('POS') or die;
	if($cf==false)$cf = array();
?>

<div class="row p-0" id="setup_page">
	<div class="col-7 p-5">
		<div class="center">
			<div class="alert alert-info"><h4> Setup</h4></div>
		</div>
		<div class="element-wrapper">
			<div class="element-box">
				<div class="row">
					<form class="form-horizontal col-12" method="POST" enctype="multipart/form-data">
					<div class="form-group col-12">
						<label>Name of Organization/ Company</label>
						<input required name="name" value="<?php echo $cf['name'] ?>" class="form-control form-control-lg" />
					</div>
					<div class="form-group col-12">
						<label>Dealership</label>
						<textarea  name="deal" class="form-control form-control-lg"><?php echo $cf['deal'] ?></textarea>
					</div>
					<div class="form-group col-12">
						<label>Office Address</label>
						<input required name="addr" value="<?php echo $cf['addr'] ?>" class="form-control form-control-lg" />
					</div>
					<div class="form-group col-12">
						<label>Company Logo</label>
						<input type="file" accept="image/*" name="file" class="form-control form-control-lg" />
					</div>
					<input type="hidden" value="setup" name="t" />
					<div class="form-group">
						<button type="submit" class="btn btn-lg btn-primary btn-block">Save</button>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>