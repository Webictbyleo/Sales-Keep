<?php
defined('POS') or die;
$sales = $db->rawquery('select sl.sn,sl.date,sl.quantity AS quantity,sl.date,sl.cost,st.min_price AS min_price,st.stock_price from sales as sl left join stocks as st on sl.product=st.id where st.id IS NOT NULL order by sl.date DESC');
	$t = count($sales);
	$d = array();
	for($i=0;$t > $i;$i++){
		$k = $sales[$i]['sn'];
			if(!isset($d[$k])){
				$d[$k] = array('sn'=>$k,'date'=>$sales[$i]['date'],'stock_price'=>0,'cost'=>0,'min_price'=>0,'quantity'=>0);
			}
			$d[$k]['stock_price'] += ($sales[$i]['stock_price'] * $sales[$i]['quantity']);
			$d[$k]['cost'] += $sales[$i]['cost'];
			$d[$k]['min_price'] += ($sales[$i]['min_price'] * $sales[$i]['quantity']) ;
			$d[$k]['quantity'] += $sales[$i]['quantity'];
			
	}
	
	$sales = array_values($d);
	

?>
<div class="row p-0" id="sales_page">
<div class="element-box d-none" id="print_box">
				<div id="corp_info" class="d-none">
					
					<div class="float-left mb-2"><?php
							if(!empty($cf['logo'])){
					echo '<img src="assets/img/'.$cf['logo'] .'" width="64" height="64" />';
							}
					?></div>
					<div class="float-right"><h4><?php echo $cf['name'] ?></h4></div>
					<div class="clearfix"></div>
					<div class="w-100 text-center"><strong>Dealership on </strong><small><?php echo $cf['deal'] ?></small></div>
					<div class="w-100 text-center mt-2"><strong>S/N:</strong><strong><span id="t_sn"></span></strong></div>
				</div>
				<hr>
				<div class="padded m-b">
					<div class="centered-header" id="cart_sum">
						<h6>Total</h6>
						<h4>₦<strong id="t_sum_cost" class="text-danger">0.00</strong></h4>
					</div>
					<div class="centered-header d-none" id="corp_addr">
						<hr>
						<h6>Transaction date </h6>
						<p id="t_date"></p>
						<hr>
						<h6>Contact us @: <?php echo $cf['addr'] ?></h6>
					</div>
					
				</div>
			</div>
	<div class="col-10 p-5 offset-1">
		<div class="element-wrapper">
		
			<div class="element-header">
				<h6>Sales</h6>
				
			</div>
			
			<div class="element-box" id="sums">
			<h4>Total sales: <span class="sums_count text-danger">0</span> | Total Sum: ₦<span class="sums_total text-danger">0</span> | Profit: ₦<span class="sums_gain text-danger">0</span></h4>
			</div>
			
			<div class="element-box">
			<div class="form-group">
			<input placeholder="Start Typing.." id="search_item" class="mac form-control" />
			</div>
				<div>
					<table class="table">
						<thead>
							<tr>
								<td>S/N</td>
								<td>Total items</td>
								<td>Date</td>
								<td>Cost</td>
								<td>Gain</td>
								
								<td></td>
							</tr>
						</thead>
						<tbody>
							<?php 
							$stkl =  array();
								if(!empty($sales)){
									$t = count($sales);
									$ts = 0;
									$g =  0;
									$tc = array();
									for($i=0;$t > $i;$i++){
										$ts += $sales[$i]['quantity'];
										$tc[] = $sales[$i]['cost'];
										$g += ($sales[$i]['cost']-$sales[$i]['stock_price']);
										echo '<tr data-id="'.$sales[$i]['sn'].'">';
										echo '<td><strong>'.$sales[$i]['sn'].'</strong></td>';
										echo '<td><strong>'.$sales[$i]['quantity'].'</strong></td>';
										echo '<td><strong>'.$sales[$i]['date'].'</strong></td>';
										echo '<td><strong class="text-danger">'.$sales[$i]['cost'].'</strong></td>';
										echo '<td><strong class="text-danger">'.($sales[$i]['cost'] - $sales[$i]['stock_price']).'</strong></td>';
										
										echo '<td><button class="btn btn-sm btn-primary" role="print" title="Print"><span class="fa fa-print"></span></button><button class="btn btn-sm btn-danger ml-3" role="del" title="Clear this record"><span class="fa fa-trash"></span></button></td>';
										echo '</tr>';
									}
									$tc = (array_sum($tc));
									
								}
							?>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
(function(){
	sales = <?php echo json_encode($sales); ?>;
	document.querySelector('#sums > h4 > span.sums_count').innerText = <?php echo $ts; ?>;
	document.querySelector('#sums > h4 > span.sums_total').innerText = <?php echo $tc; ?>;
	document.querySelector('#sums > h4 > span.sums_gain').innerText = <?php echo $g; ?>;
})();
</script>
