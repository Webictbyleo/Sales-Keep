<?php
defined('POS') or die;
$stocks = $db->rawquery('select id,code,name,state,quantity,min_price from stocks');
?>

<div class="row p-0" id="cart_page">
<div class="element-box d-none" id="print_box">
				<div id="corp_info" class="d-none">
					
					<div class="float-left mb-2"><?php
							if(!empty($cf['logo'])){
					echo '<img src="assets/img/'.$cf['logo'] .'" width="64" height="64" />';
							}
					?></div>
					<div class="float-right"><h4><?php echo $cf['name'] ?></h4></div>
					<div class="clearfix"></div>
					<div class="w-100 text-center"><strong>Dealership on </strong><small><?php echo $cf['deal'] ?></small></div>
					<div class="w-100 text-center mt-2"><strong>S/N:</strong><strong><span id="t_sn"></span></strong></div>
				</div>
				<hr>
				<div class="padded m-b">
					<div class="centered-header" id="cart_sum">
						<h6>Total</h6>
						<h4>₦<strong id="t_sum_cost" class="text-danger">0.00</strong></h4>
					</div>
					<div class="centered-header d-none" id="corp_addr">
						<hr>
						<h6>Transaction date </h6>
						<p id="t_date"></p>
						<hr>
						<h6>Contact us @: <?php echo $cf['addr'] ?></h6>
					</div>
					
				</div>
			</div>
	<div class="col-7 p-5">
			<div class="center">
			<div class="alert alert-info"><h4> Enter Product Code or Name</h4></div>
			</div>
			<div class="form-group p-5 col-6 offset-3">
				<input id="search_add_cart" class="form-control bg-faded mac" style="
    height: 55px;
    border: #047bf8ab 5px solid;
    border-radius: 10px;
">
			</div>
			<div id="search_state" class="col-6 offset-3">
				<div class="well center">
					<div class="searching d-none"><p>Searching product</p><img src="assets/img/loader.gif" /></div>
					<div class="mt-2 searched d-none"></div>
				</div>
			</div>
			
	</div>
	<div class="col-5 pt-2 pr-5">
		<div class="element-wrapper m-0 pb-0">
			<div class="element-header">
				<h6>Cart</h6>
			</div>
			<div class="element-box" id="cart_box">
				
				<table class="table">
					<thead>
						<tr>
							<td>Product</td>
							<td>Price</td>
							<td>Quantity</td>
							<td>Total</td>
							<td> </td>
						</tr>
					</thead>
					<tbody>
						
					</tbody>
				</table><hr>
				<div class="padded m-b">
					<div class="centered-header" id="cart_sum">
						<h6>Total</h6>
						<h4>₦<strong class="text-danger">0.00</strong></h4>
					</div>
					
					<div class="mt-5 center print-hidden" id="cart_actions"><button role="print" class="btn btn-lg btn-outline-secondary">Checkout</button><button role="reset" class="btn btn-lg btn-outline-danger ml-2">Reset</button><button role="clear" class="btn btn-lg btn-outline-danger ml-2">New</button></div>
				</div>
			</div>
		</div>
	</div>
        </div>
<script type="text/javascript">
	<?php echo 'stocks='.json_encode($stocks).';'; ?>
</script>